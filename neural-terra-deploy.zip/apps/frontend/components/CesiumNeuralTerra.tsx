'use client'

import { useEffect, useRef, useState } from 'react'

export default function CesiumNeuralTerra() {
  const el = useRef<HTMLDivElement>(null)
  const viewerRef = useRef<any>(null)
  const [currentPlanet, setCurrentPlanet] = useState<'earth' | 'mars'>('earth')
  const [isLoaded, setIsLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let viewer: any
    
    const initCesium = async () => {
      try {
        const Cesium = await import('cesium')

        // Set the Ion token
        ;(Cesium as any).Ion.defaultAccessToken = process.env.NEXT_PUBLIC_CESIUM_ION_TOKEN

        if (!el.current) return

        // High-res imagery + terrain
        const terrain = await Cesium.createWorldTerrainAsync()
        const imagery = new Cesium.IonImageryProvider({ assetId: 2 }) // Bing Aerial via ion

        viewer = new Cesium.Viewer(el.current, {
          imageryProvider: imagery,
          terrain,
          animation: false,
          timeline: false,
          baseLayerPicker: false,
          sceneModePicker: false,
          geocoder: false,
          navigationHelpButton: false,
          homeButton: false,
          fullscreenButton: false,
          vrButton: false,
          infoBox: false,
          selectionIndicator: false,
        })

        // Photorealistic 3D Cities (the "Google Earth" wow)
        try {
          const tileset = await (Cesium as any).createGooglePhotorealistic3DTileset()
          viewer.scene.primitives.add(tileset)
          console.log('✅ Photorealistic 3D Cities loaded!')
        } catch (e) {
          console.warn('⚠️ Photorealistic 3D Tiles unavailable:', e)
        }

        // Lighting & atmosphere for realism
        viewer.scene.globe.enableLighting = true
        viewer.scene.skyAtmosphere = new Cesium.SkyAtmosphere()
        viewer.scene.postProcessStages.bloom.enabled = true

        // Performance: only render on change
        viewer.scene.requestRenderMode = true
        viewer.scene.maximumRenderTimeChange = Infinity

        // Nice starting camera - fly to Europe to see Rotterdam area
        viewer.camera.flyTo({
          destination: Cesium.Cartesian3.fromDegrees(4.5, 51.9, 2000000), // Rotterdam area
          duration: 2.5
        })

        viewerRef.current = viewer
        setIsLoaded(true)
        console.log('✅ CesiumJS initialized successfully!')
      } catch (error) {
        console.error('❌ Failed to initialize Cesium:', error)
        setError(error instanceof Error ? error.message : 'Failed to load CesiumJS')
        setIsLoaded(true) // Still show the container
      }
    }

    initCesium()

    return () => { 
      if (viewer) {
        viewer.destroy()
      }
    }
  }, [])

  const switchToMars = () => {
    if (viewerRef.current && isLoaded && !error) {
      try {
        // Switch to Mars imagery and terrain
        viewerRef.current.scene.globe.imageryProvider = new (window as any).Cesium.SingleTileImageryProvider({
          url: '/mars-surface.jpg', // You'll need to add this image
          rectangle: (window as any).Cesium.Rectangle.fromDegrees(-180, -90, 180, 90),
        })
        
        // Change atmosphere color to red
        viewerRef.current.scene.skyAtmosphere.atmosphereLightIntensity = 10.0
        viewerRef.current.scene.skyAtmosphere.atmosphereMieCoefficient = new (window as any).Cesium.Cartesian3(0.000004, 0.000004, 0.000004)
        viewerRef.current.scene.skyAtmosphere.atmosphereRayleighCoefficient = new (window as any).Cesium.Cartesian3(0.000005902, 0.000013562, 0.000033100)
        
        setCurrentPlanet('mars')
        console.log('🪐 Switched to Mars mode')
      } catch (error) {
        console.error('Failed to switch to Mars:', error)
      }
    }
  }

  const switchToEarth = () => {
    if (viewerRef.current && isLoaded && !error) {
      try {
        // Switch back to Earth imagery
        viewerRef.current.scene.globe.imageryProvider = new (window as any).Cesium.IonImageryProvider({ assetId: 2 })
        
        // Reset atmosphere
        viewerRef.current.scene.skyAtmosphere.atmosphereLightIntensity = 10.0
        viewerRef.current.scene.skyAtmosphere.atmosphereMieCoefficient = new (window as any).Cesium.Cartesian3(0.000004, 0.000004, 0.000004)
        viewerRef.current.scene.skyAtmosphere.atmosphereRayleighCoefficient = new (window as any).Cesium.Cartesian3(0.000005902, 0.000013562, 0.000033100)
        
        setCurrentPlanet('earth')
        console.log('🌍 Switched to Earth mode')
      } catch (error) {
        console.error('Failed to switch to Earth:', error)
      }
    }
  }

  return (
    <div className="relative w-full h-full">
      <div ref={el} className="w-full h-full rounded-xl overflow-hidden bg-black" />
      
      {/* Loading indicator */}
      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="text-center text-white">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
            <div className="text-lg font-semibold mb-2">Loading Neural Terra...</div>
            <div className="text-sm text-gray-400">
              Initializing photorealistic globe with satellite imagery
            </div>
          </div>
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-red-900/80 backdrop-blur-sm">
          <div className="text-center text-white">
            <div className="text-lg font-semibold mb-2">⚠️ CesiumJS Error</div>
            <div className="text-sm text-red-200 mb-4">{error}</div>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 rounded text-sm"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Planet Controls */}
      <div className="absolute top-4 right-4 z-10">
        <div className="bg-gray-800/90 backdrop-blur-sm rounded-lg p-2 space-y-2">
          <button
            onClick={switchToEarth}
            className={`px-3 py-1 rounded text-sm transition-colors ${
              currentPlanet === 'earth' 
                ? 'bg-blue-500 text-white' 
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
            disabled={!isLoaded || !!error}
          >
            🌍 Earth
          </button>
          <button
            onClick={switchToMars}
            className={`px-3 py-1 rounded text-sm transition-colors ${
              currentPlanet === 'mars' 
                ? 'bg-red-500 text-white' 
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
            disabled={!isLoaded || !!error}
          >
            🪐 Mars
          </button>
        </div>
      </div>

      {/* Status */}
      <div className="absolute bottom-4 left-4 z-10">
        <div className="bg-gray-800/90 backdrop-blur-sm rounded-lg px-3 py-2 text-white text-sm">
          {currentPlanet === 'earth' ? '🌍 Earth Mode' : '🪐 Mars Mode'} • Neural Terra
        </div>
      </div>

      {/* Success indicator */}
      {isLoaded && !error && (
        <div className="absolute top-4 left-4 z-10">
          <div className="bg-green-800/90 backdrop-blur-sm rounded-lg px-3 py-2 text-green-200 text-sm">
            ✅ Photorealistic Globe Active
          </div>
        </div>
      )}
    </div>
  )
}