'use client'

import { useEffect, useRef, useState } from 'react'

export default function CesiumGlobe() {
  const cesiumContainer = useRef<HTMLDivElement>(null)
  const viewerRef = useRef<any>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  const [currentPlanet, setCurrentPlanet] = useState<'earth' | 'mars'>('earth')

  useEffect(() => {
    let viewer: any

    const initCesium = async () => {
      try {
        // Dynamic import to avoid SSR issues
        const Cesium = await import('cesium')
        
        // Set Cesium base URL
        ;(window as any).CESIUM_BASE_URL = '/cesium/'

        if (cesiumContainer.current) {
          viewer = new Cesium.Viewer(cesiumContainer.current, {
            animation: false,
            timeline: false,
            sceneModePicker: false,
            baseLayerPicker: false,
            navigationHelpButton: false,
            homeButton: false,
            fullscreenButton: false,
            vrButton: false,
            geocoder: false,
            infoBox: false,
            selectionIndicator: false,
            terrainProvider: Cesium.createWorldTerrain(),
            skyBox: new Cesium.SkyBox({
              sources: {
                positiveX: '/cesium/SkyBox/tycho2t3_80_px.jpg',
                negativeX: '/cesium/SkyBox/tycho2t3_80_mx.jpg',
                positiveY: '/cesium/SkyBox/tycho2t3_80_py.jpg',
                negativeY: '/cesium/SkyBox/tycho2t3_80_my.jpg',
                positiveZ: '/cesium/SkyBox/tycho2t3_80_pz.jpg',
                negativeZ: '/cesium/SkyBox/tycho2t3_80_mz.jpg',
              },
            }),
          })

          // Set initial camera position
          viewer.camera.setView({
            destination: Cesium.Cartesian3.fromDegrees(0, 0, 20000000),
            orientation: {
              heading: 0.0,
              pitch: -Cesium.Math.PI_OVER_TWO,
              roll: 0.0,
            },
          })

          // Disable default double-click behavior
          viewer.cesiumWidget.screenSpaceEventHandler.removeInputAction(Cesium.ScreenSpaceEventType.LEFT_DOUBLE_CLICK)

          viewerRef.current = viewer
          setIsLoaded(true)
        }
      } catch (error) {
        console.error('Failed to initialize Cesium:', error)
        setIsLoaded(true) // Still show the container even if Cesium fails
      }
    }

    initCesium()

    return () => {
      if (viewer) {
        viewer.destroy()
      }
    }
  }, [])

  const switchToMars = () => {
    if (viewerRef.current) {
      // Switch to Mars imagery and terrain
      viewerRef.current.scene.globe.imageryProvider = new (window as any).Cesium.SingleTileImageryProvider({
        url: '/mars-surface.jpg', // You'll need to add this image
        rectangle: (window as any).Cesium.Rectangle.fromDegrees(-180, -90, 180, 90),
      })
      
      // Change atmosphere color to red
      viewerRef.current.scene.skyAtmosphere.atmosphereLightIntensity = 10.0
      viewerRef.current.scene.skyAtmosphere.atmosphereMieCoefficient = new (window as any).Cesium.Cartesian3(0.000004, 0.000004, 0.000004)
      viewerRef.current.scene.skyAtmosphere.atmosphereRayleighCoefficient = new (window as any).Cesium.Cartesian3(0.000005902, 0.000013562, 0.000033100)
      
      setCurrentPlanet('mars')
    }
  }

  const switchToEarth = () => {
    if (viewerRef.current) {
      // Switch back to Earth imagery
      viewerRef.current.scene.globe.imageryProvider = new (window as any).Cesium.IonImageryProvider({ assetId: 1 })
      
      // Reset atmosphere
      viewerRef.current.scene.skyAtmosphere.atmosphereLightIntensity = 10.0
      viewerRef.current.scene.skyAtmosphere.atmosphereMieCoefficient = new (window as any).Cesium.Cartesian3(0.000004, 0.000004, 0.000004)
      viewerRef.current.scene.skyAtmosphere.atmosphereRayleighCoefficient = new (window as any).Cesium.Cartesian3(0.000005902, 0.000013562, 0.000033100)
      
      setCurrentPlanet('earth')
    }
  }

  return (
    <div className="relative w-full h-full">
      <div 
        ref={cesiumContainer} 
        className="w-full h-full"
        style={{ minHeight: '400px' }}
      />
      
      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-black text-white">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
            <div>Loading Neural Terra...</div>
          </div>
        </div>
      )}

      {/* Planet Controls */}
      <div className="absolute top-4 right-4 z-10">
        <div className="bg-gray-800/90 backdrop-blur-sm rounded-lg p-2 space-y-2">
          <button
            onClick={switchToEarth}
            className={`px-3 py-1 rounded text-sm transition-colors ${
              currentPlanet === 'earth' 
                ? 'bg-blue-500 text-white' 
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            🌍 Earth
          </button>
          <button
            onClick={switchToMars}
            className={`px-3 py-1 rounded text-sm transition-colors ${
              currentPlanet === 'mars' 
                ? 'bg-red-500 text-white' 
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            🪐 Mars
          </button>
        </div>
      </div>

      {/* Status */}
      <div className="absolute bottom-4 left-4 z-10">
        <div className="bg-gray-800/90 backdrop-blur-sm rounded-lg px-3 py-2 text-white text-sm">
          {currentPlanet === 'earth' ? '🌍 Earth Mode' : '🪐 Mars Mode'}
        </div>
      </div>
    </div>
  )
}
