'use client'

import { useEffect, useRef, useState } from 'react'

export default function WorkingCesiumGlobe() {
  const cesiumContainer = useRef<HTMLDivElement>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let viewer: any = null

    const initCesium = async () => {
      try {
        // Dynamic import to avoid SSR issues
        const Cesium = await import('cesium')
        
        // Set the Ion token
        ;(Cesium as any).Ion.defaultAccessToken = process.env.NEXT_PUBLIC_CESIUM_ION_TOKEN

        if (!cesiumContainer.current) {
          throw new Error('Container not found')
        }

        // Create the viewer
        viewer = new Cesium.Viewer(cesiumContainer.current, {
          animation: false,
          timeline: false,
          sceneModePicker: false,
          baseLayerPicker: false,
          geocoder: false,
          homeButton: false,
          infoBox: false,
          selectionIndicator: false,
          fullscreenButton: false,
          vrButton: false,
          navigationHelpButton: false,
        })

        // Set up the globe
        viewer.scene.globe.enableLighting = true
        viewer.scene.skyAtmosphere = new Cesium.SkyAtmosphere()

        // Fly to a nice view
        viewer.camera.flyTo({
          destination: Cesium.Cartesian3.fromDegrees(-74.0, 40.7, 10000000),
          orientation: {
            heading: Cesium.Math.toRadians(0.0),
            pitch: Cesium.Math.toRadians(-45.0),
            roll: 0.0,
          },
          duration: 2.0,
        })

        setIsLoading(false)
        console.log('✅ CesiumJS globe loaded successfully!')

      } catch (err) {
        console.error('❌ CesiumJS failed to load:', err)
        setError(err instanceof Error ? err.message : 'Failed to load globe')
        setIsLoading(false)
      }
    }

    initCesium()

    return () => {
      if (viewer) {
        viewer.destroy()
      }
    }
  }, [])

  if (error) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-red-900/20">
        <div className="text-center text-red-400">
          <div className="text-lg font-semibold mb-2">❌ Globe Error</div>
          <div className="text-sm">{error}</div>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 bg-red-600 hover:bg-red-700 rounded text-white text-sm"
          >
            Retry
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="relative w-full h-full">
      <div 
        ref={cesiumContainer} 
        className="w-full h-full"
        style={{ minHeight: '400px' }}
      />
      
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="text-center text-white">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
            <div>Loading Globe...</div>
          </div>
        </div>
      )}

      {!isLoading && !error && (
        <div className="absolute top-4 left-4 bg-green-800/90 text-green-200 px-3 py-1 rounded text-sm">
          ✅ Globe Active
        </div>
      )}
    </div>
  )
}
