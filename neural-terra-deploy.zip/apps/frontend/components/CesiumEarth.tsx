'use client'

import { useEffect, useRef } from 'react'

export default function CesiumEarth() {
  const el = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let viewer: any
    
    const initCesium = async () => {
      try {
        const Cesium = await import('cesium')

        // Token (will work without it, just with limited imagery)
        ;(Cesium as any).Ion.defaultAccessToken =
          process.env.NEXT_PUBLIC_CESIUM_ION_TOKEN || ''

        // High-res imagery + terrain
        const terrain = await Cesium.createWorldTerrainAsync()
        const imagery = new Cesium.IonImageryProvider({ assetId: 2 }) // Bing Aerial via ion

        viewer = new Cesium.Viewer(el.current!, {
          imageryProvider: imagery,
          terrain,
          animation: false,
          timeline: false,
          baseLayerPicker: false,
          sceneModePicker: false,
          geocoder: false,
          navigationHelpButton: false,
          homeButton: false,
          fullscreenButton: false,
          vrButton: false,
          infoBox: false,
          selectionIndicator: false,
        })

        // Photorealistic 3D Cities (the "Google Earth" wow)
        // Requires recent Cesium & ion access; safely try/catch.
        try {
          const tileset = await (Cesium as any).createGooglePhotorealistic3DTileset()
          viewer.scene.primitives.add(tileset)
        } catch (e) {
          console.warn('Photorealistic 3D Tiles unavailable:', e)
        }

        // Lighting & atmosphere for realism
        viewer.scene.globe.enableLighting = true
        viewer.scene.skyAtmosphere = new Cesium.SkyAtmosphere()
        viewer.scene.postProcessStages.bloom.enabled = true

        // Performance: only render on change
        viewer.scene.requestRenderMode = true
        viewer.scene.maximumRenderTimeChange = Infinity

        // Nice starting camera - fly to Europe to see Rotterdam area
        viewer.camera.flyTo({
          destination: Cesium.Cartesian3.fromDegrees(4.5, 51.9, 2000000), // Rotterdam area
          duration: 2.5
        })

        console.log('CesiumJS initialized successfully!')
      } catch (error) {
        console.error('Failed to initialize Cesium:', error)
      }
    }

    initCesium()

    return () => { 
      if (viewer) {
        viewer.destroy()
      }
    }
  }, [])

  return (
    <div className="relative w-full h-full">
      <div ref={el} className="w-full h-full rounded-xl overflow-hidden bg-black" />
      
      {/* Loading indicator */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="bg-black/50 backdrop-blur-sm rounded-lg px-4 py-2 text-white text-sm">
          Loading Neural Terra...
        </div>
      </div>
    </div>
  )
}
