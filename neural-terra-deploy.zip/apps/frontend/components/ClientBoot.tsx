'use client'
import 'cesium/Build/Cesium/Widgets/widgets.css'

export default function ClientBoot({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
